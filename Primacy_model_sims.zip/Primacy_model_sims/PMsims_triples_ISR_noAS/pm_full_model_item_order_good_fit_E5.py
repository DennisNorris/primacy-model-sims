#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""@author: dennis
This is to fit PMsims_triples_ISR_noAS. i.e., E6 post 8-2-17 (was E5 before that)




20-2-2017

Optimization terminated successfully.
         Current function value: 0.069060
         Iterations: 4
         Function evaluations: 353
*******************************************************

best_params: [ 17.03806047   0.23264869   0.73138544   3.94181051   6.65035822]
*******************************************************

running with best_params:


item_order: BOTH, peak_step: 17.0380604704, iterations: 50000, step_size: 1.0, omission_threshold: 3.94181051058, variance: 0.232648685825, omission_noise: 6.65035821719, order_decay: 0.731385442047


 [3, 1, 1, 1, 1]
order
0.97 0.97 0.97 0.87 0.68 0.50 0.43 
item
0.98 0.98 0.98 0.88 0.73 0.59 0.50 

 [1, 3, 1, 1, 1]
order
0.97 0.87 0.87 0.87 0.69 0.50 0.43 
item
0.98 0.88 0.88 0.88 0.73 0.59 0.50 

 [1, 1, 3, 1, 1]
order
0.97 0.87 0.68 0.68 0.68 0.49 0.43 
item
0.97 0.88 0.73 0.73 0.73 0.59 0.50 

 [1, 1, 1, 3, 1]
order
0.97 0.87 0.69 0.50 0.50 0.50 0.43 
item
0.98 0.88 0.73 0.59 0.59 0.59 0.50 

 [1, 1, 1, 1, 1, 1, 1]
order
0.97 0.87 0.69 0.50 0.35 0.25 0.28 
item
0.98 0.88 0.73 0.59 0.49 0.42 0.38 [ 0.97476  0.97476  0.97476  0.86664  0.68454  0.49728  0.4328   0.97612
  0.97612  0.97612  0.87812  0.72586  0.58808  0.49994]
[ 0.97408  0.8653   0.8653   0.8653   0.686    0.49876  0.43362  0.97526
  0.87736  0.87736  0.87736  0.72828  0.59008  0.50068]
[ 0.97372  0.86904  0.68222  0.68222  0.68222  0.49392  0.43362  0.97482
  0.88042  0.72562  0.72562  0.72562  0.58736  0.49928]
[ 0.9739   0.86724  0.68678  0.49738  0.49738  0.49738  0.4323   0.9751
  0.87864  0.7304   0.59042  0.59042  0.59042  0.49678]
[ 0.97406  0.86538  0.6886   0.49566  0.34532  0.25166  0.27544  0.97512
  0.87648  0.73236  0.5889   0.48796  0.41928  0.38156]
order_data_11113 [ 0.90428571  0.84214286  0.71714286  0.825       0.62678571  0.4925
  0.47035714]
item_data_11113 [ 0.92214286  0.89517857  0.85035714  0.88071429  0.72875     0.59119048
  0.51776786]
combined_11113 [ 0.9739      0.86814     0.68678     0.86664     0.68527     0.49665333
  0.615965    0.97506     0.87953     0.7304      0.87812     0.72707
  0.58850667  0.685155  ]
order_data_1111111 [ 0.9075      0.80142857  0.67785714  0.60321429  0.365       0.21642857
  0.25821429]
item_data_1111111 [ 0.93107143  0.86071429  0.78107143  0.74142857  0.51857143  0.35714286
  0.36      ]
cond_1111111 [ 0.97406  0.86538  0.6886   0.49566  0.34532  0.25166  0.27544  0.97512
  0.87648  0.73236  0.5889   0.48796  0.41928  0.38156]

RMS fit:  0.06905103853930339 



================================================================










































pm_full_model_item_order_good_fit_E5.py 
It's a slightly cleaned up version of pm_full_model_item_order_good_fit.py, just trying to fit the E5 data
The data is from Y:\data\dennis.norris\MEMORY\cowan\E5_ISR_triples_noAS\E5_summary\E5_ISR_Graphs_B&Wdn2.xlsx

This is for the 7-item lists in what was E5 - now (post 8-2-17) E6

RMS fit:  0.07083283627418187 

Optimization terminated successfully.
         Current function value: 0.070833
         Iterations: 3
         Function evaluations: 242
*******************************************************

best_params: [ 16.55387978   0.26239515   0.721047     3.24739354   7.42891634]
*******************************************************

running with best_params:


omission_noise: 7.42891634288, omit_boost: 0, step_size: 1.0, variance: 0.262395149692, item_decay: 1.0, omission_threshold: 3.24739354029, iterations: 10000, add_to_omission_gradient: 0.0, item_order: BOTH, last_item_boost: 0.0, order_decay: 0.721047003213, peak_step: 16.5538797817


 [3, 1, 1, 1, 1]
order
0.96 0.96 0.96 0.84 0.65 0.47 0.44 
item
0.96 0.96 0.96 0.86 0.72 0.60 0.52 

 [1, 3, 1, 1, 1]
order
0.96 0.83 0.83 0.83 0.65 0.47 0.43 
item
0.96 0.85 0.85 0.85 0.72 0.60 0.52 

 [1, 1, 3, 1, 1]
order
0.96 0.83 0.65 0.65 0.65 0.47 0.44 
item
0.96 0.86 0.72 0.72 0.72 0.60 0.52 

 [1, 1, 1, 3, 1]
order
0.96 0.84 0.64 0.46 0.46 0.46 0.43 
item
0.96 0.86 0.71 0.60 0.60 0.60 0.52 

 [1, 1, 1, 1, 3]
order
0.96 0.83 0.64 0.47 0.43 0.43 0.43 
item
0.96 0.86 0.71 0.60 0.51 0.51 0.51 

 [1, 1, 1, 1, 1, 1, 1]
order
0.96 0.83 0.64 0.45 0.32 0.24 0.30 
item
0.96 0.85 0.71 0.60 0.51 0.45 0.43 [ 0.9604  0.9604  0.9604  0.8351  0.6479  0.4658  0.4408  0.9626  0.9626
  0.9626  0.8571  0.7166  0.5981  0.5246]
[ 0.9614  0.8322  0.8322  0.8322  0.6489  0.4681  0.4326  0.9643  0.8534
  0.8534  0.8534  0.7201  0.6009  0.5189]
[ 0.9597  0.8344  0.6506  0.6506  0.6506  0.4664  0.4407  0.9627  0.8595
  0.7224  0.7224  0.7224  0.5998  0.5238]
[ 0.9593  0.8374  0.6362  0.4602  0.4602  0.4602  0.4297  0.9616  0.8596
  0.7088  0.5968  0.5968  0.5968  0.5177]
[ 0.9606  0.833   0.639   0.4717  0.4263  0.4263  0.4263  0.9642  0.857
  0.7107  0.6017  0.5148  0.5148  0.5148]
[ 0.9619  0.832   0.6352  0.4542  0.3156  0.2426  0.2972  0.9647  0.8544
  0.7077  0.5959  0.5069  0.4538  0.4296]
order_data_11113 [ 0.90428571  0.84214286  0.71714286  0.825       0.62678571  0.4925
  0.47035714]
item_data_11113 [ 0.92214286  0.89517857  0.85035714  0.88071429  0.72875     0.59119048
  0.51776786]
combined_11113 [ 0.96013333  0.8359      0.6362      0.8351      0.6484      0.46676667
  0.5899      0.96286667  0.85955     0.7088      0.8571      0.71835
  0.5996      0.6901    ]
order_data_1111111 [ 0.9075      0.80142857  0.67785714  0.60321429  0.365       0.21642857
  0.25821429]
item_data_1111111 [ 0.93107143  0.86071429  0.78107143  0.74142857  0.51857143  0.35714286
  0.36      ]
cond_1111111 [ 0.9619  0.832   0.6352  0.4542  0.3156  0.2426  0.2972  0.9647  0.8544
  0.7077  0.5959  0.5069  0.4538  0.4296]

RMS fit:  0.0739817574659913 



"""

import numpy as np
import math
import scipy.optimize as so



class Params (object):
    def __init__(self,iterations,peak_step, step_size, variance,  order_decay, omission_threshold, omission_noise, item_order ):
        self.iterations = iterations
        self.peak_step = peak_step
        self.step_size = step_size
        self.variance = variance

        self.order_decay = order_decay
        self.omission_threshold = omission_threshold
        self.omission_noise = omission_noise 
        self.item_order = item_order # 'ORDER' to fit order, 'ITEM' to fit item, 'BOTH' to fit both
      
        
        




# simple primacy model noisy choice recall
# the effective params are peak_step, variance, decay, omission_threshold, omission_noise
def recall_PM_basic(params,list_structure):
        """
        simple primacy model noisy choice recall
        the effective params are peak_step, variance, decay, omission_threshold, omission_noise
        """
        order_recall = np.zeros(len(list_structure))
        item_recall = np.zeros(len(list_structure))
        length = len(list_structure)
        print('\n\n',list_structure)


        for iteration in range(params.iterations):
            suppressed = np.zeros(length) # we're going to add a big -ve number to this for suppressed items
            
            gradient = np.arange(params.peak_step, params.peak_step - length * params.step_size , -params.step_size)
            
            if len(gradient) != len(list_structure):
                print(params.peak_step, params.peak_step - length * params.step_size , params.step_size)
           # print('gradient',gradient)
             # add noise to 
            for list_pos in range(length): # go through the list
                noisy_gradient = gradient + suppressed + np.random.normal(0,params.variance,length) # add noise to the gradient
             #   print(len(noisy_gradient), len(suppressed))
                
                idx = np.argmax(noisy_gradient) # pick biggest
               # print('noisy gradient',  noisy_gradient,  idx)

                gradient *= params.order_decay # decay
                suppressed[idx] = -9999999999999999999999999999999 # suppress regardless of whether correct
                
                omit_noise = np.random.normal(0,params.omission_noise,1) # generate sample of omission noise
                if idx == list_pos: # if correct in position
                    #  only score as correct if greater than omission threshold
                    if (noisy_gradient[idx] + omit_noise) >  params.omission_threshold: # if not ommitted
                        order_recall[idx] += 1
                        
                 # now item scoring:
                 #  only score as correct if greater than omission threshold
                if (noisy_gradient[idx] + omit_noise) > params.omission_threshold: 
                        item_recall[idx] += 1
                        

        out_order = []
        print('order')
        for i in range(length):
            for j in range(list_structure[i]):
                print("{:.2f} ".format(order_recall[i]/params.iterations), end="")  
                out_order.append(order_recall[i]/params.iterations)
        print()
        
        print('item')
        out_item = []
        for i in range(length):
            for j in range(list_structure[i]):
                print("{:.2f} ".format(item_recall[i]/params.iterations), end="")
                out_item.append(item_recall[i]/params.iterations)
                
     #   print('\nxxxx', out_order, out_item)
      #  print('\nxxxx', np.concatenate((np.asarray(out_order),np.asarray(out_item)) )) 
        if  params.item_order == 'BOTH':
            return np.concatenate((np.asarray(out_order),np.asarray(out_item)) )
            
        elif params.item_order == 'ITEM':
            return(np.asarray(out_item))
        elif params.item_order == 'ORDER':
            return(np.asarray(out_order))
            # returns the serial posn curve - here it's the in-position curve
        else:
           print('unknown option:', params.item_order)
           
        


    
def run_basic_PM_once(p): # runs throuh all conditions for specified number of iterations.
    """
    takes vector of params to optimise
    
    """

    iterations = 50000


# this lot are just dummies to initialise the parmeter class
 
    peak_step = 10.0  
   # omission_threshold = 7.0  # smaller means more omissions
    step_size = 1.0    # should fix paras so this is 1, as it's not really a free param
    variance = 1.0
  #  item_decay = 0.75 # using this for the omission gradient and the order gradient
    order_decay = 0.95
    omission_threshold = 0.0
    omission_noise = 1.0

   
    item_order = 'BOTH'

    params = Params(iterations,peak_step, step_size, variance, order_decay, omission_threshold, omission_noise, item_order )




    
    #item_decay, omission_threshold, omission_noise
    params.peak_step = p[0]
    params.variance = p[1]
    params.order_decay = p[2]
    params.omission_threshold = p[3]
    params.omission_noise = p[4]
    
    if params.variance <= 0.1: # keep variance within sensible range
        return 1.0
    if params.peak_step < 6.0: # i.e. never let the activation go below 0
        return 1.0
    if params.omission_noise <= 0.0:
        return 1.0
    
    if  params.order_decay <= 0.1:
        return 1.0
        
    # print everything in the params class
    attrs = vars(params)
    print(', '.join("%s: %s" % item for item in attrs.items()))
    

    
    # this is the expt 5 strict position scoring data - same as the graph in the paper
    '''

NB - there were no 11113 lists ending in a triple
1111111	1	0.9075	0.801428571	0.677857143	0.603214286	0.365	0.216428571	0.258214286	0.595238095
1111111	3	0	0	0	0	0	0	0	0
11113	1	0.904285714	0.842142857	0.717142857	0.825	0.626785714	0.4925	0.470357143	0.734642857
11113	3	0.933214286	0.941428571	0.929285714	0.876785714	0.845714286	0.788571429	0	0.885833333
133	1	0.972857143	0	0	0.858928571	0	0	0.761428571	0.370459184
133	3	0.971428571	0.968928571	0.963928571	0.955357143	0.923928571	0.93	0.930714286	0.952261905

    '''
    
    order_data_1111111 = np.array([0.9075,	    0.801428571,	0.677857143,	0.603214286,	0.365,	        0.216428571,	0.258214286])
    order_data_11113 =   np.array([.904285714,	0.842142857,	0.717142857,	0.825,	        0.626785714,	0.4925,	        0.470357143])
    item_data_1111111 = np.array([0.931071429,	0.860714286,	0.781071429,	0.741428571,	0.518571429,	0.357142857,	0.36])
    item_data_11113 =   np.array([0.922142857,	0.895178571,	0.850357143,	0.880714286,	0.72875,	    0.591190476,	0.517767857])

    
    cond_31111 = recall_PM_basic(params,[3,1,1,1,1])
    
    cond_13111 = recall_PM_basic(params,[1,3,1,1,1])
    
    cond_11311 = recall_PM_basic(params,[1,1,3,1,1])
    
    cond_11131 = recall_PM_basic(params,[1,1,1,3,1])
 #   cond_11113 = recall_PM_basic(params,[1,1,1,1,3]) # there were no 11113 lists ending in a triple
    
    
    cond_1111111 = recall_PM_basic(params,[1,1,1,1,1,1,1])
    
    if params.item_order == 'BOTH':
        combined_11113 = np.zeros(len(order_data_1111111) + len(item_data_1111111))
    else:
        combined_11113 = np.zeros(len(order_data_1111111))
        
    print(cond_31111)
    print(cond_13111)
    print(cond_11311)  
    print(cond_11131)
#    print(cond_11113)
    print(cond_1111111)
    
    
    
     
    combined_11113[0] = (cond_13111[0] + cond_11311[0] +  cond_11131[0])/3
    combined_11113[1] = (cond_11311[1] +  cond_11131[1])/2
    combined_11113[2] = cond_11131[2] 
    combined_11113[3] = cond_31111[3]
    combined_11113[4] = (cond_31111[4]  + cond_13111[4])/2
    combined_11113[5] = (cond_31111[5]  + cond_13111[5] + cond_11311[5])/3
    combined_11113[6] = (cond_31111[5]  + cond_13111[5] + cond_11311[5] + cond_11131[0])/4
    
    if params.item_order == 'BOTH':
        list_length = len(order_data_1111111)

        combined_11113[0 + list_length] = (cond_13111[0 + list_length] + cond_11311[0 + list_length] +  cond_11131[0 + list_length])/3
        combined_11113[1 + list_length] = (cond_11311[1 + list_length] +  cond_11131[1 + list_length])/2
        combined_11113[2 + list_length] = cond_11131[2 + list_length] 
        combined_11113[3 + list_length] = cond_31111[3 + list_length]
        combined_11113[4 + list_length] = (cond_31111[4 + list_length]  + cond_13111[4 + list_length])/2
        combined_11113[5 + list_length] = (cond_31111[5 + list_length]  + cond_13111[5 + list_length] + cond_11311[5 + list_length])/3
        combined_11113[6 + list_length] = (cond_31111[5 + list_length]  + cond_13111[5 + list_length] + cond_11311[5 + list_length] + cond_11131[0 + list_length])/4
        

    


    print('order_data_11113', order_data_11113)
    print('item_data_11113', item_data_11113)
    print('combined_11113', combined_11113)
    print('order_data_1111111', order_data_1111111)
    print('item_data_1111111', item_data_1111111)
    print('cond_1111111', cond_1111111)

    if params.item_order == 'ORDER':
        x = order_data_11113 - combined_11113
        y = order_data_1111111 - cond_1111111
    if params.item_order == 'ITEM':
        x = item_data_11113 - combined_11113
        y = item_data_1111111 - cond_1111111
    elif params.item_order == 'BOTH':
        x = np.concatenate((order_data_11113, item_data_11113)) - combined_11113
        y = np.concatenate((order_data_1111111, item_data_1111111)) - cond_1111111
 #   print(x)
    x *= x
    y *= y
    RMS = math.sqrt((x.mean() + y.mean())/2.0)
    
    print('\nRMS fit: ',RMS,'\n')
    return RMS
      

def main():


# the params we are interested in:
    peak_step = 16.55387978
    variance = 0.26239515  # variance of noise in noisy choice.
    order_decay = 0.721047
    omission_threshold = 3.24739354
    omission_noise = 7.42891634
    
    initial_guess = np.array([ peak_step, variance, order_decay, omission_threshold, omission_noise])
    run_basic_PM_once(initial_guess) # see what hte initial guess is like
    # I tried to pass the param class as args to this but it didn't like it.
    # consequentyl I've put the parameters in run_once itself.
  #  exit()
    best_params = so.fmin_powell(run_basic_PM_once, initial_guess, maxfun=1000, full_output=0)
    print('*******************************************************\n')
    print('best_params:', best_params)
    print('*******************************************************\n')
    print('running with best_params:\n\n')
    run_basic_PM_once(best_params)
 


if __name__ == '__main__':


#    if _platform == "win32" or _platform == "win64":
#        dummy = stdin.readline()  # on windows this stops cmd.exe window from closing
        # until you hit return
    main()
    
    