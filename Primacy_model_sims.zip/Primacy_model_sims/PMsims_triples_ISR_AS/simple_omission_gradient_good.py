#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""@author: dennis

2-12-16

pm_og_opt3.py

this just uses peak_step and omission_noise

RMS fit:  0.057886902723978576 

Optimization terminated successfully.
         Current function value: 0.056094
         Iterations: 4
         Function evaluations: 120
*******************************************************

best_params: [ 3.02210511  2.75463388]
*******************************************************

running with best_params:


add_to_omission_gradient: 12, omission_threshold: 0.0, order_decay: 0.95, item_decay: 1.0, step_size: 1.0, peak_step: 3.02210510837, sigma: 0.85, last_item_boost: 0.0, omission_noise: 2.75463388487, iterations: 10000
[3, 1, 1, 1]
0.86 0.86 0.86 0.76 0.64 0.50 
[1, 3, 1, 1]
0.86 0.77 0.77 0.77 0.65 0.49 
[1, 1, 3, 1]
0.87 0.78 0.65 0.65 0.65 0.50 
[1, 1, 1, 3]
0.86 0.77 0.65 0.50 0.50 0.50 
[1, 1, 1, 1, 1, 1]
0.87 0.77 0.64 0.50 0.37 0.24 
data_1113 [0.864404667, 0.7735715, 0.702857, 0.809286, 0.5857145, 0.460238333]
combined_1113 [ 0.8643      0.77185     0.6457      0.7591      0.6474      0.49736667]
data_111111 [0.882857143, 0.799285714, 0.647142857, 0.417142857, 0.281428571, 0.355714286]
cond_111111 [ 0.8652  0.7664  0.6408  0.5038  0.3694  0.2382]

RMS fit:  0.05878184436257593 




**********************************************************************************

30-11-16 - change to do omissions on gradient

I've added print out of omissions. What we want is for the omissions to be
lower after a triple at the start. But that means the triple has somehow
got to decrease the number of omissions, which we can only do by changing
the omission threshold contingent on the triple before it. How could
we motivate that? Stop the gradient going down if you're in a triple?
We're actually doing that now when a triple is treated as a single item.




"""

import numpy as np
import math
import scipy.optimize as so


class Params (object):
    def __init__(self, iterations, peak_step, step_size, sigma, item_decay, order_decay, omission_threshold, omission_noise, add_to_omission_gradient, last_item_boost):
        self.iterations = iterations
        self.peak_step = peak_step
        self.step_size = step_size
        self.sigma = sigma
        self.item_decay = item_decay
        self.order_decay = order_decay
        self.omission_threshold = omission_threshold
        self.omission_noise = omission_noise
        self.add_to_omission_gradient = add_to_omission_gradient

        self.last_item_boost = last_item_boost  # this doesn't work too well.
        '''
        last_item_boost of about 2.5 is almost OK for 111111s but with 1113s it's effectively boosting
        the 4th item, which goes up too much. We'll just leave this as zero.       
        
        '''


# simple primacy model noisy choice recall
def recall_PM(params, list_structure, steps):  # steps not used
    """
    """
    recall = np.zeros(len(list_structure))
    omissions = np.zeros(len(list_structure))
#        omission_gradient = np.zeros(len(list_structure))
    item_recalled_anywhere = np.zeros(len(list_structure))
    item_anywhere_this_trial = np.zeros(len(list_structure))
    noisy_gradient = np.zeros(len(list_structure))
    length = len(list_structure)
    print(list_structure)

# would it be cleaner to have a separate omission gradient?

    for i in range(params.iterations):
        # start with this as 1s, cos we're going to set suppressed items to a big -ve no.
        item_suppressed = np.ones(length)
        # start with this as 1s, cos we're going to set suppressed items to a big -ve no.
        order_suppressed = np.ones(length)
        # and multiply the activations by this, so suppressed items get 'taken out'
        # now create the gradient
        gradient = np.arange(params.peak_step, params.peak_step -
                             len(list_structure) * params.step_size, -params.step_size)
        item_anywhere_this_trial.fill(0)

        '''
            this version reduces the step at each posn in an effort to stop the
            performance on singles dropping off too much at the end.
            It works really well on the E4 item data.
            Now we need to add the order to it. Not sure how to do
            that if we'e already done omissions before order. 
            Somehow we'll need to assume that omitted items have place holders
            whose order can be confused, so we just need to add a bit of order
            error into this.
            
            
            '''

        tmp_step = params.step_size
        noisy_gradient[0] = params.peak_step
        current_step = params.peak_step
        for list_pos in range(1, length):
            current_step = current_step - tmp_step
            noisy_gradient[list_pos] = current_step
            tmp_step *= params.item_decay
    #    print(noisy_gradient)
        noisy_gradient += np.random.normal(0,
                                           params.omission_noise, len(noisy_gradient))
        noisy_gradient[-1] += params.last_item_boost
     #   print(noisy_gradient)
        item_suppressed[:] = noisy_gradient
     #   print(suppressed)
        # now turn suppressed into 0 for suppressed, 1 for not suppressed
        item_suppressed[item_suppressed < params.omission_threshold] = 0.0
        item_suppressed[item_suppressed > params.omission_threshold] = 1.0
      #  print(suppressed)

        # for items anywhere we just add suppressed
        item_recalled_anywhere += item_suppressed

        '''
            Now we need to add order recall on top of the omissions. I think we have to do this
            by doing a standard PM where omissions are held as place holders - as though you
            know there's something there, by you can't remember what.        
                      
            '''
        noisy_gradient = gradient + params.add_to_omission_gradient + \
            np.random.normal(0, params.omission_noise, len(
                gradient))  # add noise to the gradient
        order_suppressed.fill(1)  # start with nothing suppressed

        for list_pos in range(length):  # go through the list
            # add noise to the gradient
            noisy_gradient = gradient + \
                np.random.normal(0, params.sigma, len(gradient))
            # pick biggest not yet suppressed
            idx = np.argmax(noisy_gradient * order_suppressed)

          #  print('noisy gradient',  noisy_gradient* suppressed, idx)
            # for j in range(list_structure[list_pos]):
            gradient *= params.order_decay  # decay
           # noisy_gradient[idx] = -99999999999999999999999.9  # effectively suppress it

            order_suppressed[idx] = 0  # suppress

            if idx == list_pos and item_suppressed[idx] > 0:
                recall[idx] += 1

    '''
        out = []
        for i in range(length):
            for j in range(list_structure[i]):
                print("{:.2f} ".format(recall[i]/params.iterations), end="")
                out.append(recall[i]/params.iterations)
        print()
        '''

    out = []
    for i in range(length):
        for j in range(list_structure[i]):
            print("{:.2f} ".format(
                item_recalled_anywhere[i]/params.iterations), end="")
            out.append(item_recalled_anywhere[i]/params.iterations)
    print()

    # returns the serial posn curve - here it's the item-anywhere curve
    return np.asarray(out)


# runs throuh all conditions fo rspecified number of iterations.
def run_once(p):

    iterations = 10000

 # peak_step and omissions can be replaced by setting peak_step to peak_step - omission
    # doesn't matter for order now that omissions are being dealt with seperately
    peak_step = 10.0
   # omission_threshold = 7.0  # smaller means more omissions
    step = 1.0    # should fix paras so this is 1, as it's not really a free param
    noise = 0.85
  #  item_decay = 0.75 # using this for the omission gradient and the order gradient
    order_decay = 0.95
    item_decay = 1.0
    omission_threshold = 0.0
    last_item_boost = 0.0
  #  omission_noise = 2.5 # this is used

    # Hmm - sort this out. It changes the effective slope and interacts with omission(threshold)- should be poss to do without it.
    add_to_omission_gradient = 12

    params = Params(iterations, peak_step, step, noise, item_decay, order_decay,
                    omission_threshold, 0, add_to_omission_gradient, last_item_boost)


#item_decay, omission_threshold, omission_noise
  #  params.item_decay = p[0]
    params.peak_step = p[0]
    params.omission_noise = p[1]

    attrs = vars(params)
# {'kids': 0, 'name': 'Dog', 'color': 'Spotted', 'age': 10, 'legs': 2, 'smell': 'Alot'}
# now dump this in some way or another
    print(', '.join("%s: %s" % item for item in attrs.items()))

    extra_step = 2  # steps not used

    data_111111 = [0.882857143, 0.799285714, 0.647142857,
                   0.417142857, 0.281428571, 0.355714286]
    data_1113 = [0.864404667, 0.7735715,   0.702857,
                 0.809286,	 0.5857145,   0.460238333]

    cond_3111 = recall_PM(params, [3, 1, 1, 1], [extra_step, 1, 1])

    cond_1311 = recall_PM(params, [1, 3, 1, 1], [extra_step, extra_step, 1])

    cond_1131 = recall_PM(params, [1, 1, 3, 1], [1, extra_step, extra_step])

    cond_1113 = recall_PM(params, [1, 1, 1, 3], [1, 1, extra_step])

    cond_111111 = recall_PM(params, [1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1])

    combined_1113 = np.zeros(len(data_111111))

    '''
    this lot now makes the same numbers in the composite graph of all the singletons in 13 lists
    in the paper
    '''
    combined_1113[0] = (cond_1311[0] + cond_1131[0] + cond_1113[0])/3
    combined_1113[1] = (cond_1131[1] + cond_1113[1])/2
    combined_1113[2] = cond_1113[2]
    combined_1113[3] = cond_3111[3]
    combined_1113[4] = (cond_3111[4] + cond_1311[4])/2
    combined_1113[5] = (cond_3111[5] + cond_1311[5] + cond_1131[5])/3

    print('data_1113', data_1113)
    print('combined_1113', combined_1113)
    print('data_111111', data_111111)
    print('cond_111111', cond_111111)

    x = np.asarray(data_1113 - combined_1113)
    y = np.asarray(data_111111 - cond_111111)
 #   print(x)
    x *= x
    y *= y
    RMS = math.sqrt((x.mean() + y.mean()) / 2.0)

    print('\nRMS fit: ', RMS, '\n')
    return RMS


def main():
    #    iterations = 10000

 # peak_step and omissions can be replaced by setting peak_step to peak_step - omission
 #   peak_step = 10.0  # doesn't matter for order now that omissions are being dealt with seperately
    omission_threshold = 7.0  # smaller means more omissions
  #  step = 1.5    # should fix paras so this is 1, as it's not really a free param
  #  noise = 0.85
    item_decay = 0.75  # using this for the omission gradient and the order gradient
  #  order_decay = 0.95

    omission_noise = 2.5  # this is used

    peak_step = 3.39643639
    omission_noise = 1.6529127733333333

    run_once(np.asarray([3.13439852,  2.8938711]))
   # run_once(np.asarray([3.13439852,  2.8938711]))
 #   exit()

#    add_to_omission_gradient = 12  # Hmm - sort this out. It changes the effective slope and interacts with omission(threshold)- should be poss to do without it.

  #  params = Params(iterations, peak_step, step, noise, item_decay, order_decay, omission_threshold, omission_noise, add_to_omission_gradient )

# the params we are interested in:
    initial_guess = np.array([peak_step, omission_noise])
    run_once(initial_guess)
    # I tried to pass the param class as args to this but it didn't like it - no idea why
    # consequentyl I've put the parameters in run_once itself.

    best_params = so.fmin_powell(
        run_once, initial_guess, maxfun=1000, full_output=0)
    print('*******************************************************\n')
    print('best_params:', best_params)
    print('*******************************************************\n')
    print('running with best_params:\n\n')
    run_once(best_params)


if __name__ == '__main__':

    #    if _platform == "win32" or _platform == "win64":
    #        dummy = stdin.readline()  # on windows this stops cmd.exe window from closing
    # until you hit return
    main()
