#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""@author: dennis

14-2-2017 - I've plugged the best params back into this and it delivers the same results,
so this is the correct version of the simple PM with no extra steps of decay.
i.e. it treats chunks as though they were single items so a 1113 will effectively be a 4-item list.


   params.peak_step = p[0]
    params.variance = p[1]
    params.order_decay = p[2]
    params.omission_threshold = p[3]
    params.omission_noise = p[4]


Optimization terminated successfully.
         Current function value: 0.052390
         Iterations: 8
         Function evaluations: 732
*******************************************************

best_params: [ 9.7921845   0.43875814  0.86858298  4.74462099  3.56484765]
*******************************************************

running with best_params:


omission_noise: 3.56484764772, peak_step: 9.79218450132, order_decay: 0.868582981365, item_decay: 1.0, omit_boost: 0, step_size: 1.0, last_item_boost: 0.0, item_order: BOTH, add_to_omission_gradient: 0.0, variance: 0.438758144751, iterations: 50000, omission_threshold: 4.74462099037


 [3, 1, 1, 1]
order
0.87 0.87 0.87 0.69 0.51 0.42
item
0.92 0.92 0.92 0.79 0.63 0.49

 [1, 3, 1, 1]
order
0.87 0.69 0.69 0.69 0.51 0.42
item
0.92 0.79 0.79 0.79 0.63 0.48

 [1, 1, 3, 1]
order
0.87 0.69 0.52 0.52 0.52 0.42
item
0.92 0.79 0.64 0.64 0.64 0.49

 [1, 1, 1, 3]
order
0.87 0.69 0.52 0.42 0.42 0.42
item
0.92 0.80 0.63 0.48 0.48 0.48

 [1, 1, 1, 1, 1, 1]
order
0.87 0.69 0.52 0.36 0.25 0.21
item
0.92 0.79 0.63 0.48 0.36 0.27 [ 0.8703   0.8703   0.8703   0.69084  0.51458  0.42036  0.91724  0.91724
  0.91724  0.79286  0.62854  0.48544]
[ 0.87198  0.68712  0.68712  0.68712  0.51306  0.41818  0.9191   0.79166
  0.79166  0.79166  0.62948  0.4829 ]
[ 0.87146  0.69036  0.51888  0.51888  0.51888  0.42224  0.91668  0.7932
  0.63502  0.63502  0.63502  0.48614]
[ 0.87112  0.69302  0.51768  0.41894  0.41894  0.41894  0.91844  0.79612
  0.63206  0.48182  0.48182  0.48182]
[ 0.87128  0.68514  0.51568  0.36116  0.25302  0.21202  0.91786  0.78716
  0.63086  0.47952  0.36124  0.26746]
order_data_1113 [ 0.82892857  0.66892857  0.65214286  0.70035714  0.47071429  0.39357143]
item_data_1113 [ 0.86440467  0.7735715   0.702857    0.809286    0.5857145   0.46023833]
combined_1113 [ 0.87152     0.69169     0.51768     0.69084     0.51382     0.42026
  0.9023      0.79466     0.63206     0.79286     0.62901     0.48482667]
order_data_111111 [ 0.83214286  0.705       0.54464286  0.28285714  0.16464286  0.21071429]
item_data_111111 [ 0.88285714  0.79928571  0.64714286  0.41714286  0.28142857  0.35571429]
cond_111111 [ 0.87128  0.68514  0.51568  0.36116  0.25302  0.21202  0.91786  0.78716
  0.63086  0.47952  0.36124  0.26746]

RMS fit:  0.05366203148101769





"""

import numpy as np
import math
import scipy.optimize as so


class Params (object):
    def __init__(self, iterations, peak_step, step_size, variance, item_decay, order_decay, omission_threshold, omission_noise, add_to_omission_gradient, last_item_boost, omit_boost, item_order):
        self.iterations = iterations
        self.peak_step = peak_step
        self.step_size = step_size
        self.variance = variance
        self.item_decay = item_decay
        self.order_decay = order_decay
        self.omission_threshold = omission_threshold
        self.omission_noise = omission_noise
        self.add_to_omission_gradient = add_to_omission_gradient
        self.omit_boost = omit_boost
        self.last_item_boost = last_item_boost  # this doesn't work too well.
        self.item_order = item_order


# simple primacy model noisy choice recall
# the effective params are peak_step, variance, decay, omission_threshold
def recall_PM_basic(params, list_structure, steps):  # steps not used
    """

    """
    order_recall = np.zeros(len(list_structure))
    item_recall = np.zeros(len(list_structure))
    length = len(list_structure)
    print('\n\n', list_structure)

    for iteration in range(params.iterations):
        # we're going to add a big -ve number to this for suppressed items
        suppressed = np.zeros(length)

        gradient = np.arange(params.peak_step, params.peak_step -
                             length * params.step_size, -params.step_size)

        if len(gradient) != len(list_structure):
            print(params.peak_step, params.peak_step -
                  length * params.step_size, params.step_size)
       # print('gradient',gradient)
         # add noise to
        for list_pos in range(length):  # go through the list
            noisy_gradient = gradient + suppressed + \
                np.random.normal(0, params.variance,
                                 length)  # add noise to the gradient
         #   print(len(noisy_gradient), len(suppressed))

            idx = np.argmax(noisy_gradient)  # pick biggest
           # print('noisy gradient',  noisy_gradient,  idx)

            gradient *= params.order_decay  # decay
            # suppress regardless of whether correct
            suppressed[idx] = -9999999999999999999999999999999

            # generate sample of omission noise
            omit_noise = np.random.normal(0, params.omission_noise, 1)
            if idx == list_pos:  # if correct in position
                #  only score as correct if greater than omission threshold
                # if not ommitted
                if (noisy_gradient[idx] + omit_noise) > params.omission_threshold:
                    order_recall[idx] += 1

             # now item scoring:
             #  only score as correct if greater than omission threshold
            if (noisy_gradient[idx] + omit_noise) > params.omission_threshold:
                item_recall[idx] += 1

    out_order = []
    print('order')
    for i in range(length):
        for j in range(list_structure[i]):
            print("{:.2f} ".format(order_recall[i]/params.iterations), end="")
            out_order.append(order_recall[i]/params.iterations)
    print()

    print('item')
    out_item = []
    for i in range(length):
        for j in range(list_structure[i]):
            print("{:.2f} ".format(item_recall[i]/params.iterations), end="")
            out_item.append(item_recall[i]/params.iterations)

 #   print('\nxxxx', out_order, out_item)
  #  print('\nxxxx', np.concatenate((np.asarray(out_order),np.asarray(out_item)) ))
    if params.item_order == 'BOTH':
        return np.concatenate((np.asarray(out_order), np.asarray(out_item)))

    elif params.item_order == 'ITEM':
        return(np.asarray(out_item))
    elif params.item_order == 'ORDER':
        return(np.asarray(out_order))
        # returns the serial posn curve - here it's the in-position curve
    else:
        print('unknown option:', params.item_order)


# omission version, with optional order which isn't used at the moment

def recall_PM_omission(params, list_structure, steps):  # steps not used
    """
    """
    recall = np.zeros(len(list_structure))
    omissions = np.zeros(len(list_structure))
#        omission_gradient = np.zeros(len(list_structure))
    item_recalled_anywhere = np.zeros(len(list_structure))
    item_anywhere_this_trial = np.zeros(len(list_structure))
    noisy_gradient = np.zeros(len(list_structure))
    length = len(list_structure)
    print(list_structure)

# would it be cleaner to have a separate omission gradient?

    for i in range(params.iterations):
        # start with this as 1s, cos we're going to set suppressed items to a big -ve no.
        item_suppressed = np.ones(length)
        # start with this as 1s, cos we're going to set suppressed items to a big -ve no.
        order_suppressed = np.ones(length)
        # and multiply the activations by this, so suppressed items get 'taken out'
        # now create the gradient
        gradient = np.arange(params.peak_step, params.peak_step -
                             len(list_structure) * params.step_size, -params.step_size)
        item_anywhere_this_trial.fill(0)


        tmp_step = params.step_size
        noisy_gradient[0] = params.peak_step
        current_step = params.peak_step
        for list_pos in range(1, length):
            current_step = current_step - tmp_step
            noisy_gradient[list_pos] = current_step
            tmp_step *= params.item_decay
    #    print(noisy_gradient)
            noisy_gradient += np.random.normal(0,
                                               params.omission_noise, len(noisy_gradient))

            # WHY WAS THIS NOT COMMENTED OUT PRE-14-2-17? Because it was set to 0
        # we're not using this as it's a bit crude
        noisy_gradient[-1] += params.last_item_boost
        item_suppressed[:] = noisy_gradient
     #   print(suppressed)
        # now turn suppressed into 0 for suppressed, 1 for not suppressed
        item_suppressed[item_suppressed < params.omission_threshold] = 0.0
        item_suppressed[item_suppressed > params.omission_threshold] = 1.0
      #  print(suppressed)

        # for items anywhere we just add suppressed
        item_recalled_anywhere += item_suppressed

        '''
            Now we need to add order recall on top of the omissions. I think we have to do this
            by doing a standard PM where omissions are held as place holders - as though you
            know there's something there, by you can't remember what.

            '''
        noisy_gradient = gradient + params.add_to_omission_gradient + \
            np.random.normal(0, params.omission_noise, len(
                gradient))  # add noise to the gradient

        order_suppressed.fill(1)  # start with nothing suppressed

        for list_pos in range(length):  # go through the list
            # add noise to the gradient
            noisy_gradient = gradient + \
                np.random.normal(0, params.variance, len(gradient))
            # pick biggest not yet suppressed
            idx = np.argmax(noisy_gradient * order_suppressed)

          #  print('noisy gradient',  noisy_gradient* suppressed, idx)
            # for j in range(list_structure[list_pos]):
            gradient *= params.order_decay  # decay
           # noisy_gradient[idx] = -99999999999999999999999.9  # effectively suppress it

            order_suppressed[idx] = 0  # suppress

            if idx == list_pos and item_suppressed[idx] > 0:
                recall[idx] += 1

    out = []
    for i in range(length):
        for j in range(list_structure[i]):
            print("{:.2f} ".format(
                item_recalled_anywhere[i]/params.iterations), end="")
            out.append(item_recalled_anywhere[i]/params.iterations)
    print()

    # returns the serial posn curve - here it's the item-anywhere curve
    return np.asarray(out)


# runs through all conditions for specified number of iterations.
def run_once_omissions(p):
    """
    takes 3-element vector of item_decay, peak_step, omission_noise

    """

    iterations = 10000

 # peak_step and omissions can be replaced by setting peak_step to peak_step - omission
    # doesn't matter for order now that omissions are being dealt with seperately
    peak_step = 10.0
   # omission_threshold = 7.0  # smaller means more omissions
    step = 1.0    # should fix paras so this is 1, as it's not really a free param
    noise = 0.85
  #  item_decay = 0.75 # using this for the omission gradient and the order gradient
    order_decay = 0.95
    item_decay = 1.0
    omission_threshold = 0.0

  #  omission_noise = 2.5 # this is used

    # Hmm - sort this out. It changes the effective slope and interacts with omission(threshold)- should be poss to do without it.
    add_to_omission_gradient = 12
    item_order = 'ITEM'
    params = Params(iterations, peak_step, step, noise, item_decay, order_decay,
                    omission_threshold, 0, add_to_omission_gradient, 0, item_order)

    params.peak_step = p[0]
    params.omission_noise = p[1]

    attrs = vars(params)
# {'kids': 0, 'name': 'Dog', 'color': 'Spotted', 'age': 10, 'legs': 2, 'smell': 'Alot'}
# now dump this in some way or another
    print(', '.join("%s: %s" % item for item in attrs.items()))

    extra_step = 2  # steps not used

    data_111111 = [0.882857143, 0.799285714, 0.647142857,
                   0.417142857, 0.281428571, 0.355714286]
    data_1113 = [0.864404667, 0.7735715,   0.702857,
                 0.809286,	 0.5857145,   0.460238333]

    cond_3111 = recall_PM_omission(params, [3, 1, 1, 1], [extra_step, 1, 1])

    cond_1311 = recall_PM_omission(
        params, [1, 3, 1, 1], [extra_step, extra_step, 1])

    cond_1131 = recall_PM_omission(
        params, [1, 1, 3, 1], [1, extra_step, extra_step])

    cond_1113 = recall_PM_omission(params, [1, 1, 1, 3], [1, 1, extra_step])

    cond_111111 = recall_PM_omission(
        params, [1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1])

    combined_1113 = np.zeros(len(data_111111))

    '''
    this lot now makes the same numbers in the composite graph of all the singletons in 13 lists
    in the paper
    '''
    combined_1113[0] = (cond_1311[0] + cond_1131[0] + cond_1113[0])/3
    combined_1113[1] = (cond_1131[1] + cond_1113[1])/2
    combined_1113[2] = cond_1113[2]
    combined_1113[3] = cond_3111[3]
    combined_1113[4] = (cond_3111[4] + cond_1311[4])/2
    combined_1113[5] = (cond_3111[5] + cond_1311[5] + cond_1131[5])/3

    print('data_1113', data_1113)
    print('combined_1113', combined_1113)
    print('data_111111', data_111111)
    print('cond_111111', cond_111111)

    x = data_1113 - combined_1113
 #   print(x)
    x *= x

    print('\nRMS fit: ', math.sqrt(x.mean()), '\n')
    return math.sqrt(x.mean())


# runs throuh all conditions fo rspecified number of iterations.
def run_basic_PM_once(p):

    iterations = 50000

 # peak_step and omissions can be replaced by setting peak_step to peak_step - omission
    # doesn't matter for order now that omissions are being dealt with seperately
    peak_step = 10.0
   # omission_threshold = 7.0  # smaller means more omissions
    step_size = 1.0    # should fix paras so this is 1, as it's not really a free param
    noise = 0.85
  #  item_decay = 0.75 # using this for the omission gradient and the order gradient
    order_decay = 0.95
    omission_threshold = 0.0
    omission_noise = 1.0
    last_item_boost = 0.0
  #  omission_noise = 2.5 # this is used
    add_to_omission_gradient = 0.0
    item_decay = 1.0
    omit_boost = 0
    item_order = 'BOTH'
    variance = 1.0
    params = Params(iterations, peak_step, step_size, variance, item_decay, order_decay, omission_threshold,
                    omission_noise, add_to_omission_gradient, last_item_boost, omit_boost, item_order)

#item_decay, omission_threshold, omission_noise
    params.peak_step = p[0]
    params.variance = p[1]
    params.order_decay = p[2]
    params.omission_threshold = p[3]
    params.omission_noise = p[4]

    if params.variance <= 0.1:  # keep variance within sensible range
        return 1.0
    if params.peak_step < 6.0:  # i.e. never let the activation go below 0
        return 1.0
    if params.omission_noise <= 0.0:
        return 1.0

    if params.item_decay <= 0.1 or params.order_decay <= 0.1:
        return 1.0

    # print everything in the params class
    attrs = vars(params)
    print(', '.join("%s: %s" % item for item in attrs.items()))

    extra_step = 2  # steps not used

    # this is the expt 4 strict position scoring data - same as the graph in the paper
    order_data_111111 = np.array(
        [0.832142857, 0.705, 0.544642857, 0.282857143, 0.164642857, 0.210714286])
    order_data_1113 = np.array(
        [0.828928571, 0.668928571, 0.652142857, 0.700357143, 0.470714286, 0.393571429])
    item_data_111111 = np.array(
        [0.882857143, 0.799285714, 0.647142857, 0.417142857, 0.281428571, 0.355714286])
    item_data_1113 = np.array(
        [0.864404667, 0.7735715,   0.702857,	   0.809286,	 0.5857145,   0.460238333])

    cond_3111 = recall_PM_basic(params, [3, 1, 1, 1], [extra_step, 1, 1])

    cond_1311 = recall_PM_basic(params, [1, 3, 1, 1], [
                                extra_step, extra_step, 1])

    cond_1131 = recall_PM_basic(params, [1, 1, 3, 1], [
                                1, extra_step, extra_step])

    cond_1113 = recall_PM_basic(params, [1, 1, 1, 3], [1, 1, extra_step])

    cond_111111 = recall_PM_basic(params, [1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1])

    if params.item_order == 'BOTH':
        combined_1113 = np.zeros(
            len(order_data_111111) + len(item_data_111111))
    else:
        combined_1113 = np.zeros(len(order_data_111111))

    print(cond_3111)
    print(cond_1311)
    print(cond_1131)
    print(cond_1113)
    print('cond_111111', cond_111111)

    '''
    this lot now makes the same numbers in the composite graph of all the singletons in 13 lists
    in the paper
    '''

    combined_1113[0] = (cond_1311[0] + cond_1131[0] + cond_1113[0])/3
    combined_1113[1] = (cond_1131[1] + cond_1113[1])/2
    combined_1113[2] = cond_1113[2]
    combined_1113[3] = cond_3111[3]
    combined_1113[4] = (cond_3111[4] + cond_1311[4])/2
    combined_1113[5] = (cond_3111[5] + cond_1311[5] + cond_1131[5])/3

    if params.item_order == 'BOTH':
        combined_1113[0 + 6] = (cond_1311[0 + 6] +
                                cond_1131[0 + 6] + cond_1113[0])/3
        combined_1113[1 + 6] = (cond_1131[1 + 6] + cond_1113[1 + 6])/2
        combined_1113[2 + 6] = cond_1113[2 + 6]
        combined_1113[3 + 6] = cond_3111[3 + 6]
        combined_1113[4 + 6] = (cond_3111[4 + 6] + cond_1311[4 + 6])/2
        combined_1113[5 + 6] = (cond_3111[5 + 6] +
                                cond_1311[5 + 6] + cond_1131[5 + 6])/3

    print('order_data_1113', order_data_1113)
    print('item_data_1113', item_data_1113)
    print('combined_1113', combined_1113)
    print('order_data_111111', order_data_111111)
    print('item_data_111111', item_data_111111)
    print('cond_111111', cond_111111)

    if params.item_order == 'ORDER':
        x = order_data_1113 - combined_1113
        y = order_data_111111 - cond_111111
    if params.item_order == 'ITEM':
        x = item_data_1113 - combined_1113
        y = item_data_111111 - cond_111111
    elif params.item_order == 'BOTH':
        x = np.concatenate((order_data_1113, item_data_1113)) - combined_1113
        y = np.concatenate((order_data_111111, item_data_111111)) - cond_111111
 #   print(x)
    x *= x
    y *= y
    RMS = math.sqrt((x.mean() + y.mean())/2.0)

    print('\nRMS fit: ', RMS, '\n')
    return RMS


def main():
    #    iterations = 10000

 # peak_step and omissions can be replaced by setting peak_step to peak_step - omission
 #   peak_step = 10.0  # doesn't matter for order now that omissions are being dealt with seperately
    omission_threshold = 2.0  # smaller means more omissions
  #  step = 1.5    # should fix paras so this is 1, as it's not really a free param
  #  noise = 0.85
    item_decay = 0.75  # using this for the omission gradient and the order gradient
    order_decay = 0.8

    peak_step = 14
    variance = 2.0
    omission_noise = 2.75463388

   # run_basic_PM_once(np.asarray([ peak_step, variance, order_decay, omission_threshold]))
   # run_once(np.asarray([1.0,  3.13439852,  2.8938711]))
   # exit()

#    add_to_omission_gradient = 12  # Hmm - sort this out. It changes the effective slope and interacts with omission(threshold)- should be poss to do without it.

  #  params = Params(iterations, peak_step, step, noise, item_decay, order_decay, omission_threshold, omission_noise, add_to_omission_gradient )

# the params we are interested in:
    peak_step = 9.7921845
    variance = 0.43875814
    order_decay = 0.86858298
    omission_threshold = 4.74462099
    omission_noise = 3.56484765
    initial_guess = np.array(
        [peak_step, variance, order_decay, omission_threshold, omission_noise])
    run_basic_PM_once(initial_guess)
    # I tried to pass the param class as args to this but it didn't like it - no idea why
    # consequentyl I've put the parameters in run_once itself.
  #  exit()
    best_params = so.fmin_powell(
        run_basic_PM_once, initial_guess, maxfun=1000, full_output=0)
    print('*******************************************************\n')
    print('best_params:', best_params)
    print('*******************************************************\n')
    print('running with best_params:\n\n')
    run_basic_PM_once(best_params)


if __name__ == '__main__':

    #    if _platform == "win32" or _platform == "win64":
    #        dummy = stdin.readline()  # on windows this stops cmd.exe window from closing
        # until you hit return
    main()
