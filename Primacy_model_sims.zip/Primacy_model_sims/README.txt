The two directories here contain the simulations for experiments 5 &
6. The python progs are Python3

The python simulation programs have the best parameters coded into them
as a starting point
